#!/bin/bash
 
while getopts "i:o:" opt; do
  case $opt in
    i)
      inputpath="$OPTARG"
      ;;
    o)
      outputpath="$OPTARG" 
      ;;
  esac
done

python main.py --input $inputpath --output $outputpath --model model/model.pkl