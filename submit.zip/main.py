import argparse
from cProfile import label
import os
import pickle
from lxml.etree import XML

class Pipline():
    def __init__(self):
        self.tfidf=None
        self.lsa=None
        self.svm=None
    
    def inference(self,x):
        '''
        x:batch_size x sent_nums x words
        
        '''
        tfidf_vectors=[self.tfidf.transform(x_sub).toarray().mean(axis=0) for x_sub in x]
        lsa_vectors=self.lsa.transform(tfidf_vectors)
        return lsa_vectors
    
    def predict(self,x):

        lsa_vectors=self.inference(x)

        res=self.svm.predict(lsa_vectors)

        return res 

def getModel(modelPath):
    with open(modelPath,"rb") as f:
        model=pickle.load(f)
        return model



def generateResult(author_id,label):
    label_map={1:"I",0:"NI"}
    info=f'''<author id="{author_id}"
                    lang="en"
                    type="{label_map[label]}"
                    />'''
    return info

def generate(model,inputPath,outputPath):
    xmls=os.listdir(inputPath)
    for xml in xmls:
        input_file_path=os.path.join(inputPath,xml)
        out_file_path=os.path.join(outputPath,xml)

        with open(input_file_path,"r",encoding="utf-8") as inputFile,open(out_file_path,"w") as ouputFile:
                xmlObj=XML(inputFile.read())
                text=xmlObj.xpath("//document//text()")
                pred=model.predict([text])[0]
                predict_info=generateResult(xml[:-4],pred)
                ouputFile.write(predict_info)
                inputFile.close()
                ouputFile.close()
    print("Finished!!!!")


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",help="the input path of test data")
    parser.add_argument("--output",help="the output path of predict data with model")
    parser.add_argument("--model",help="model path")
    args=parser.parse_args()
    model=getModel(args.model)
    generate(model,args.input,args.output)


if __name__=="__main__":
    main()